class Reverse{
    constructor(n) {
        this.n = n
    }
    output(){
        var newString = "";
        for (var i = this.n.length - 1; i >= 0; i--) {
            newString += this.n[i];
        }
            return newString;
    }
}
const data = new Reverse("Iqbal");
console.log(data.output());