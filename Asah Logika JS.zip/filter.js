class Filter{
    constructor(n) {
        this.n = n
    }

    output(){
        let result = [];
        for (let i = 0; i <this.n; i++){
            if (i < 4){
                result.push(i);
            }
        }
        return result;
    }
}

const data = new Filter(10);
console.log(data.output());